//
// Created by HLCaptain on 2019. 11. 24..
//

#include "snakeGame.h"
#include <stdlib.h>
#include <stdio.h>
#include "debugmalloc.h"
#include "debugmalloc-impl.h"
#include <stdbool.h>
#include "SDL2/SDL.h"
#include "snakeMenu.h"
#include <SDL2/SDL2_gfxPrimitives.h>


//spawns a head inside the map
void spawnSnake(int mapHeight, int mapLength, int **gameMap, int margin, snakeEntity *snakeHead)
{
    snakeHead->x = (rand() % (mapLength - margin * 2)) + margin + 1;
    snakeHead->y = (rand() % (mapHeight - margin * 2)) + margin + 1;
    snakeHead->next = NULL;
    gameMap[snakeHead->y - 1][snakeHead->x - 1] = 1;
}

//spawns an apple inside the map
void spawnApple(int mapHeight, int mapLength, int **gameMap, snakeEntity *apple)
{
    apple->x = (rand() % (mapLength - 2)) + 2;
    apple->y = (rand() % (mapHeight - 2)) + 2;
    while (gameMap[apple->y - 1][apple->x - 1] == 1) //making sure coordinates dont match up
    {
        apple->x = (rand() % (mapLength - 2)) + 2;
        apple->y = (rand() % (mapHeight - 2)) + 2;
    }
    apple->next = NULL;
    gameMap[apple->y - 1][apple->x - 1] = 3;
}

//reads height values from file
int giveHeight(FILE *map)
{
    int l, h, s;
    fscanf(map, "%d %d %d", &l, &h, &s);
    return h;
}

//reads length value from file
int giveLength(FILE *map)
{
    int l, h, s;
    fscanf(map, "%d %d %d", &l, &h, &s);
    return l;
}
//reads size value from file
int giveSizeOfBlock(FILE *map)
{
    int l, h, s;
    fscanf(map, "%d %d %d", &l, &h, &s);
    return s;
}

//creates map with given height and length values, places walls as well
int **createMap(int mapHeight, int mapLength)
{
    int **gameMap = (int **) malloc(sizeof(int *) * mapHeight);
    gameMap[0] = (int *) malloc(sizeof(int) * mapLength * mapHeight);
    for (int l = 1; l < mapHeight; l++)
    {
        gameMap[l] = gameMap[0] + l * mapLength;
    }
    for (int i = 1; i <= mapHeight; i++)
    { //creating walls
        for (int k = 1; k <= mapLength; k++)
        {
            gameMap[i - 1][k - 1] = 0;
            if (i == 1 || i == mapHeight || k == 1 || k == mapLength)
                gameMap[i - 1][k - 1] = 5; //the state "5" means, the block is a wall
        }
    }
    return gameMap;
}

snakeEntity *snakeHeadPointer(snakeEntity *snakeTail)
{
    snakeEntity *h = (snakeEntity *) malloc(sizeof(snakeEntity));
    if (snakeTail->next == NULL)
    {
        snakeTail->next = h;
        return h;
    }
    else
    {
        snakeEntity *p = snakeTail;
        while (p->next != NULL)
            p = p->next;
        p->next = h;
        return h;
    }
}

snakeEntity *snakeNeckPointer(snakeEntity *snakeTail)
{
    if (snakeTail->next == NULL)
        return snakeTail;
    else
    {
        snakeEntity *n = snakeTail;
        while (n->next != NULL)
            n = n->next;
        return n;
    }
}

snakeEntity *snakeBeforeNeckPointer(snakeEntity *snakeTail)
{
    if (snakeTail->next == NULL || snakeTail->next->next == NULL)
        return snakeTail;
    else
    {
        snakeEntity *n = snakeTail;
        while (n->next->next != NULL)
            n = n->next;
        return n;
    }
}

void snakeNextStateDraw(snakeEntity *snakeTail, int **gameMap)
{
    snakeEntity *t = snakeTail;
    snakeEntity *p = t;
    gameMap[t->y - 1][t->x - 1] = 0;
    while (t->next != NULL)
    {
        t->x = t->next->x;
        t->y = t->next->y;
        p = t;
        t = t->next;
    }
    free(t);
    p->next = NULL;
    t = snakeTail;
    while (t != NULL)
    {
        gameMap[t->y - 1][t->x - 1] = 1;
        t = t->next;
    }
}

int **mapNextState(int **gameMap, snakeEntity *snakeTail, snakeEntity *apple, int input, int mapHeight, int mapLength)
{
    if (input == 0) //with no input, nothing happens
        return gameMap;
    if (input == 6) //code 34 means, return to the main menu
    {
        gameMap[0][0] = 34; //rule
        return gameMap; //returning the new state of the map
    }

    snakeEntity *n = snakeNeckPointer(snakeTail); //n is the new neck of the snake
    snakeEntity *beforeNeck = snakeBeforeNeckPointer(snakeTail);
    snakeEntity *h = snakeHeadPointer(snakeTail); //h will point to the new head of the snake
    //new head of the snake begins at the neck
    h->x = n->x;
    h->y = n->y;
    h->next = NULL;

    //according to the input, the these will determine the new coordinates of the head
    if (input == 1)
    {
        if (beforeNeck->y == h->y - 1 && beforeNeck->x == h->x) //head will go to the opposite way, if the input was the opposite in the last move (left-right, up-down)
            h->y++;
        else
            h->y--;
    }
    else if (input == 2)
    {
        if (beforeNeck->y == h->y + 1 && beforeNeck->x == h->x)
            h->y--;
        else
            h->y++;
    }
    else if (input == 3)
    {
        if (beforeNeck->y == h->y && beforeNeck->x == h->x - 1)
            h->x++;
        else
            h->x--;
    }
    else if (input == 4)
    {
        if (beforeNeck->y == h->y && beforeNeck->x == h->x + 1)
            h->x--;
        else
            h->x++;
    }
    if (gameMap[h->y - 1][h->x - 1] == 3) //snake reaches apple
    {
        gameMap[h->y - 1][h->x - 1] = 1; //checking
        spawnApple(mapHeight, mapLength, gameMap, apple);
        return gameMap;
    }
    else if (gameMap[h->y - 1][h->x - 1] == 1) //snake reaches itself
    {
        gameMap[0][0] = 420; //game over because of biting itself
        return gameMap;
    }
    else if (gameMap[h->y - 1][h->x - 1] == 5) //snake reaches the wall
    {
        gameMap[0][0] = 69; //game over because of going to the wall
        return gameMap;
    }
    else
        snakeNextStateDraw(snakeTail, gameMap);
    return gameMap;
}

void freeGameMap(int mapHeight, int mapLength, int **gameMap) //frees up the allocated memory
{
    free(gameMap[0]);
    free(gameMap);
}

void freeLinkedList(snakeEntity *linkedList) //frees up the linked list
{
    snakeEntity *n;
    while (linkedList != NULL)
    {
        n = linkedList->next;
        free(linkedList);
        linkedList = n;
    }
}

void quitGame(int mapHeight, int mapLength, snakeEntity *apple, int **gameMap, snakeEntity *snakeBody) //frees up everything
{
    free(apple);
    freeLinkedList(snakeBody);
    freeGameMap(mapHeight, mapLength, gameMap);
}

void drawMapState(int mapLength, int mapHeight, int sizeOfBlock,  int **gameMap, SDL_Renderer *renderer)
{
    for(int i=0; i<mapHeight; i++)
    {
        for(int j=0; j<mapLength; j++)
        {
            if(gameMap[j][i]==0)
                rectangleRGBA(renderer, i*sizeOfBlock, j*sizeOfBlock, i*sizeOfBlock+sizeOfBlock, j*sizeOfBlock+sizeOfBlock, 0x40, 0x40, 0x40, 0xFF); //gray are empty blocks
            if(gameMap[j][i]==1)
                rectangleRGBA(renderer, i*sizeOfBlock, j*sizeOfBlock, i*sizeOfBlock+sizeOfBlock, j*sizeOfBlock+sizeOfBlock, 0x00, 0xFF, 0x00, 0xFF); //green is the snake
            if(gameMap[j][i]==3)
                rectangleRGBA(renderer, i*sizeOfBlock, j*sizeOfBlock, i*sizeOfBlock+sizeOfBlock, j*sizeOfBlock+sizeOfBlock, 0xFF, 0x00, 0x00, 0xFF); //red is the apple
            if(gameMap[j][i]==5 || gameMap[j][i]==34 || gameMap[j][i]==420 || gameMap[j][i]==69)
                rectangleRGBA(renderer, i*sizeOfBlock, j*sizeOfBlock, i*sizeOfBlock+sizeOfBlock, j*sizeOfBlock+sizeOfBlock, 0x00, 0x00, 0xFF, 0xFF); //blue are the walls

        }
    }
    SDL_RenderPresent(renderer);

}

void inputHandling(int *input, int **gameMap, snakeEntity *snakeBody, snakeEntity *apple, int mapHeight, int mapLength)
{
    SDL_Event event;
    SDL_PollEvent(&event);
    switch(event.type){
            case SDL_QUIT: *input = 5; return;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym){
                    case SDLK_LEFT: *input = 3; gameMap = mapNextState(gameMap, snakeBody, apple, *input, mapHeight, mapLength); return;
                    case SDLK_RIGHT: *input = 4; gameMap = mapNextState(gameMap, snakeBody, apple, *input, mapHeight, mapLength); return;
                    case SDLK_UP: *input = 1; gameMap = mapNextState(gameMap, snakeBody, apple, *input, mapHeight, mapLength); return;
                    case SDLK_DOWN: *input = 2; gameMap = mapNextState(gameMap, snakeBody, apple, *input, mapHeight, mapLength); return;
                    case SDLK_ESCAPE: *input = 6; return;
            }
    }
}

int gameIni()
{
    //opening the file
    FILE *map;
    map = fopen("map.txt", "r");
    if (map == NULL)
    {
        printf("Cannot locate the map file! F\nQuitting to the menu...");
        return 46; //rule
    }
    //reading from files
    int mapHeight = giveHeight(map);
    int mapLength = giveLength(map);
    int sizeOfBlock = giveSizeOfBlock(map);
    //sdl initialization
    SDL_Window *window;
    SDL_Renderer *renderer;
    sdl_init(sizeOfBlock*mapLength, sizeOfBlock*mapHeight, &window, &renderer, "A kigyok kigyoznak ");

    int delay = 200; //ms, the game updates every <delay> ms by itself
    int margin = 2; //distance from walls
    int **gameMap = createMap(mapHeight, mapLength);
    snakeEntity *snakeBody = (snakeEntity *) malloc(sizeof(snakeEntity)); //creates snake pointer
    snakeEntity *apple = (snakeEntity *) malloc(sizeof(snakeEntity)); //creates apple pointer
    spawnApple(mapHeight, mapLength, gameMap, apple);
    spawnSnake(mapHeight, mapLength, gameMap, margin, snakeBody);
    int input = 0;
    int currentTime, lastTime = 0; //timer
    printf("To quit to the main menu, press ESC, to quit the game, press the red x on the upper right corner!\n");
    while (input != 5 || input != 6) //printing out the state of the game
    {
        currentTime = SDL_GetTicks();
        if (currentTime > lastTime + delay) { //every <delay> amount of ms, this if statement is true
            lastTime = currentTime;
            gameMap = mapNextState(gameMap, snakeBody, apple, input, mapHeight, mapLength);
            if (gameMap[0][0] == 69 || gameMap[0][0] == 420 || gameMap[0][0] == 34) //exiting state
                break;
        }
        if (gameMap[0][0] == 69 || gameMap[0][0] == 420 || gameMap[0][0] == 34) //exiting state
            break;
        SDL_Delay(10);
        inputHandling(&input, gameMap, snakeBody, apple, mapHeight, mapLength);
        if (gameMap[0][0] == 69 || gameMap[0][0] == 420 || gameMap[0][0] == 34) //exiting state
            break;
        drawMapState(mapLength, mapHeight, sizeOfBlock, gameMap, renderer);
    }
    //closing out sdl
    SDL_Quit();
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    int rValue;
    //determining, which exit input to return
    if (gameMap[0][0] == 69 || gameMap[0][0] == 420 || gameMap[0][0] == 34) //returning error code
        rValue = gameMap[0][0];
    else
        rValue = input;
    //freeing the allocated memory
    quitGame(mapHeight, mapLength, apple, gameMap, snakeBody);
    fclose(map);
    return rValue;



}
