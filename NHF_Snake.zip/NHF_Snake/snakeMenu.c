//
// Created by HLCaptain on 2019. 11. 24..
//

#include "snakeMenu.h"
#include <stdlib.h>
#include <stdio.h>
#include "debugmalloc.h"
#include "debugmalloc-impl.h"
#include "snakeGame.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>


void sdl_init(int length, int height, SDL_Window **pwindow, SDL_Renderer **prenderer, char*title) {
    if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {
        SDL_Log("Nem indithato az SDL: %s", SDL_GetError());
        exit(1);
    }
    SDL_Window *window = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, length, height, 0);
    if (window == NULL) {
        SDL_Log("Nem hozhato letre az ablak: %s", SDL_GetError());
        exit(1);
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (renderer == NULL) {
        SDL_Log("Nem hozhato letre a megjelenito: %s", SDL_GetError());
        exit(1);
    }
    SDL_RenderClear(renderer);

    *pwindow = window;
    *prenderer = renderer;
}
void writeTextToWindow(char *text1, TTF_Font *font, SDL_Color color, SDL_Renderer *renderer, SDL_Rect hova, SDL_Surface *felirat, SDL_Texture *felirat_t)
{
    felirat = TTF_RenderUTF8_Blended(font, text1, color);
    felirat_t = SDL_CreateTextureFromSurface(renderer, felirat);
    hova.x = (640 - felirat->w) / 2;
    hova.w = felirat->w;
    hova.h = felirat->h;
    SDL_RenderCopy(renderer, felirat_t, NULL, &hova);
    SDL_FreeSurface(felirat);
    SDL_DestroyTexture(felirat_t);
}

void gameMenu()
{
    SDL_Window *window;
    SDL_Renderer *renderer;

    TTF_Init();
    TTF_Font *font = TTF_OpenFont("LiberationSerif-Regular.ttf", 32);
    if (!font) {
        SDL_Log("Nem sikerult megnyitni a fontot! %s\n", TTF_GetError());
        exit(1);
    }
    SDL_Surface *felirat, *felirat420, *felirat34, *felirat69, *felirat46;
    SDL_Texture *felirat_t, *felirat_t420, *felirat_t34, *felirat_t69, *felirat_t46;
    SDL_Rect hova = { 0, 100, 0, 0 };
    SDL_Rect hova2 = { 0, 200, 0, 0 };
    SDL_Rect hovaError = { 0, 300, 0, 0 };

    SDL_Color white = {255, 255, 255};
    SDL_Color red = {255, 0, 0};

    int gameOver = 0;
    bool quit = false;
    char text1[] = "Press ENTER to PLAY Snake";
    char text2[] = "Press ESC to QUIT";
    char text420[] = "You ate yourself... F";
    char text34[] = "Welcome to the Main Menu!";
    char text69[] = "Bruh, you have gone head to head to the wall...";
    char text46[] = "No map file detected!";
    while (quit == false)
    {
        sdl_init(640, 480, &window, &renderer, "Main Menu");
        writeTextToWindow(text1, font, white, renderer, hova, felirat, felirat_t);
        writeTextToWindow(text2, font, white, renderer, hova2, felirat, felirat_t);
        if (gameOver == 420)
            writeTextToWindow(text420, font, red, renderer, hovaError, felirat420, felirat_t420);
        if (gameOver == 34)
            writeTextToWindow(text34, font, red, renderer, hovaError, felirat34, felirat_t34);
        if (gameOver == 69)
            writeTextToWindow(text69, font, red, renderer, hovaError, felirat69, felirat_t69);
        if (gameOver == 46)
            writeTextToWindow(text46, font, red, renderer, hovaError, felirat46, felirat_t46);
        while (quit == false) //input handling
        {
            SDL_RenderPresent(renderer);
            SDL_Event event;
            SDL_WaitEvent(&event);
            switch (event.type) {
                case SDL_QUIT:{
                    quit = true;
                    gameOver = 5;
                    SDL_Quit(); break;}
                case SDL_KEYDOWN:
                    switch (event.key.keysym.sym){
                        case SDLK_ESCAPE: {
                            quit = true;
                            gameOver = 5;
                            SDL_Quit(); break;}
                        case SDLK_RETURN: {
                            SDL_Quit();
                            gameOver = gameIni();
                            quit = true; break;}
                    }
            }
        }
        quit=false;

        if (gameOver == 5) //quiting condition
            quit=true;
    }
    //sending love
    printf("Hope, you had fun, BYE!!!");

    //quiting from sdl
    TTF_CloseFont(font);
    SDL_Quit();
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
}
