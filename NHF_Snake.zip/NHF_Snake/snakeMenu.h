//
// Created by HLCaptain on 2019. 11. 24..
//

#ifndef NHF_SNAKE_SNAKEMENU_H
#define NHF_SNAKE_SNAKEMENU_H

#include "snakeMenu.h"
#include <stdlib.h>
#include <stdio.h>
#include "debugmalloc.h"
#include "debugmalloc-impl.h"
#include "snakeGame.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_ttf.h>
#include <stdbool.h>

void gameMenu();

void writeTextToWindow(char *text, TTF_Font *font, SDL_Color color, SDL_Renderer *renderer, SDL_Rect hova, SDL_Surface *felirat, SDL_Texture *felirat_t);

void sdl_init(int length, int height, SDL_Window **pwindow, SDL_Renderer **prenderer, char*title);

#endif //NHF_SNAKE_SNAKEMENU_H
