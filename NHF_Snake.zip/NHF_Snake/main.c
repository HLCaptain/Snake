#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "debugmalloc.h"
#include "debugmalloc-impl.h"
#include "snakeGame.h"
#include "snakeMenu.h"

int main(int argc, char *argv[])
{
    srand(time(0));
    gameMenu();
    return 0;
}


