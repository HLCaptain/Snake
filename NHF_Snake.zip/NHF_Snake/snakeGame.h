//
// Created by HLCaptain on 2019. 11. 24..
//

#include <stdlib.h>
#include <stdio.h>
#include "debugmalloc.h"
#include "debugmalloc-impl.h"

#ifndef NHF_SNAKE_SNAKEGAME_H
#define NHF_SNAKE_SNAKEGAME_H

typedef struct snakeEntity
{ //linked lists for the entities
    int y;
    int x;
    struct snakeEntity *next;
} snakeEntity;

//spawns a head inside the map
void spawnSnake(int mapHeight, int mapLength, int **gameMap, int margin, snakeEntity *snakeHead);

//spawns an apple inside the map
void spawnApple(int mapHeight, int mapLength, int **gameMap, snakeEntity *apple);

//reads height values from file
int giveHeight(FILE *map);

//reads length value from file
int giveLength(FILE *map);

//reads size value from file
int giveSizeOfBlock(FILE *map);

//creates map with given height and length values
int **createMap(int mapHeight, int mapLength);

snakeEntity *snakeHeadPointer(snakeEntity *snakeTail);

snakeEntity *snakeNeckPointer(snakeEntity *snakeTail);

snakeEntity *snakeBeforeNeckPointer(snakeEntity *snakeTail);

void snakeNextStateDraw(snakeEntity *snakeTail, int **gameMap);

int **mapNextState(int **gameMap, snakeEntity *snakeTail, snakeEntity *apple, int input, int mapHeight, int mapLength);

void freeGameMap(int mapHeight, int mapLength, int **gameMap);

void freeLinkedList(snakeEntity *linkedList);

void quitGame(int mapHeight, int mapLength, snakeEntity *apple, int **gameMap, snakeEntity *snakeBody);

void inputHandling(int *input, int **gameMap, snakeEntity *snakeTail, snakeEntity *apple, int mapHeight, int mapLength);

int gameIni();

#endif //NHF_SNAKE_SNAKEGAME_H



